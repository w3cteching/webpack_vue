# webpack_vue

    webpack搭建前端环境-lesson
# 使用说明

   第一步：先克隆
   
   git clone git@github.com:w3cteching/webpack_vue.git

   第二步：进入webpack_vue目录

   再执行  npm install 并回车自动安装依赖
