//console.log('我是index.js')

//let tools = require('./untils/tools');


//ES6模块化

import tools from './untils/tools'
//引入css
import './style/test.scss'

import logo from './imgs/logo.jpg'


var result1 = tools.sum(120, 180)
//var result2 = tools.jian(100, 20)


//console.log('求和的结果：',result1)
//console.log('减的结果：',result2)

//将值输出到页面上

function createElement(logo) {

    var odiv = document.createElement('div');
    var oimg = document.createElement('img');
    oimg.src = logo
    
   odiv.appendChild(oimg);
    
    return odiv;
}

document.body.appendChild(createElement(logo));


