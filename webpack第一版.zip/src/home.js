function log(str) {
    console.log(str)
}

log('hello,多入口')